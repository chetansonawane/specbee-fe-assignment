<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yao', 'lao', 'lao', 'kao', 'mao', 'zhe', 'qi', 'gou', 'gou', 'gou', 'die', 'die', 'er', 'shua', 'ruan', 'nai',
  0x10 => 'nai', 'duan', 'lei', 'ting', 'zi', 'geng', 'chao', 'hao', 'yun', 'ba', 'pi', 'yi', 'si', 'qu', 'jia', 'ju',
  0x20 => 'huo', 'chu', 'lao', 'lun', 'ji', 'tang', 'ou', 'lou', 'nou', 'jiang', 'pang', 'zha', 'lou', 'ji', 'lao', 'huo',
  0x30 => 'you', 'mo', 'huai', 'er', 'yi', 'ding', 'ye', 'da', 'song', 'qin', 'yun', 'chi', 'dan', 'dan', 'hong', 'geng',
  0x40 => 'zhi', 'pan', 'nie', 'dan', 'zhen', 'che', 'ling', 'zheng', 'you', 'wa', 'liao', 'long', 'zhi', 'ning', 'tiao', 'er',
  0x50 => 'ya', 'tie', 'gua', 'xu', 'lian', 'hao', 'sheng', 'lie', 'pin', 'jing', 'ju', 'bi', 'di', 'guo', 'wen', 'xu',
  0x60 => 'ping', 'cong', 'ding', 'ni', 'ting', 'ju', 'cong', 'kui', 'lian', 'kui', 'cong', 'lian', 'weng', 'kui', 'lian', 'lian',
  0x70 => 'cong', 'ao', 'sheng', 'song', 'ting', 'kui', 'nie', 'zhi', 'dan', 'ning', 'qie', 'ni', 'ting', 'ting', 'long', 'yu',
  0x80 => 'yu', 'zhao', 'si', 'su', 'yi', 'su', 'si', 'zhao', 'zhao', 'rou', 'yi', 'le', 'ji', 'qiu', 'ken', 'cao',
  0x90 => 'ge', 'bo', 'huan', 'huang', 'yi', 'ren', 'xiao', 'ru', 'zhou', 'yuan', 'du', 'gang', 'rong', 'gan', 'cha', 'wo',
  0xA0 => 'chang', 'gu', 'zhi', 'han', 'fu', 'fei', 'fen', 'pei', 'pang', 'jian', 'fang', 'zhun', 'you', 'na', 'ang', 'ken',
  0xB0 => 'ran', 'gong', 'yu', 'wen', 'yao', 'qi', 'pi', 'qian', 'xi', 'xi', 'fei', 'ken', 'jing', 'tai', 'shen', 'zhong',
  0xC0 => 'zhang', 'xie', 'shen', 'wei', 'zhou', 'die', 'dan', 'fei', 'ba', 'bo', 'qu', 'tian', 'bei', 'gua', 'tai', 'zi',
  0xD0 => 'ku', 'zhi', 'ni', 'ping', 'zi', 'fu', 'pang', 'zhen', 'xian', 'zuo', 'pei', 'jia', 'sheng', 'zhi', 'bao', 'mu',
  0xE0 => 'qu', 'hu', 'ke', 'chi', 'yin', 'xu', 'yang', 'long', 'dong', 'ka', 'lu', 'jing', 'nu', 'yan', 'pang', 'kua',
  0xF0 => 'yi', 'guang', 'hai', 'ge', 'dong', 'chi', 'jiao', 'xiong', 'xiong', 'er', 'an', 'heng', 'pian', 'neng', 'zi', 'gui',
];
